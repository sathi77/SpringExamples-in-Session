package com.srini;

public class MyImplClass implements MyInterFace 
{
	public void m1(){
		
		System.out.println("Am in business method..");

	}
}
