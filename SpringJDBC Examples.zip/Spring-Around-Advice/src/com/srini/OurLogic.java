package com.srini;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class OurLogic 
{
	public static void main(String args[])
	{
		BeanFactory context = new XmlBeanFactory(new ClassPathResource("spconfig.xml"));
		
		MyInterFace inter =(MyInterFace)context.getBean("id3");
		inter.m1();
	}
}
